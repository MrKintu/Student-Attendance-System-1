<!DOCTYPE html>
<html lang="zxx" class="no-js">

<head>
    <!-- Mobile Specific Meta -->
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Favicon-->
    <link rel="shortcut icon" href="img/fav.png">
    <!-- Author Meta -->
    <meta name="author" content="Colorlib">
    <!-- Meta Description -->
    <meta name="description" content="">
    <!-- Meta Keyword -->
    <meta name="keywords" content="">
    <!-- meta character set -->
    <meta charset="UTF-8">
    <!-- Site Title -->
    <title>Add student</title>

    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,400,300,500,600,700" rel="stylesheet">
    <!--
			CSS
			============================================= -->
    <link rel="stylesheet" href="css/linearicons.css">=
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/nice-select.css">
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/main.css">
    <!--BOOTSTRAP-->
    <!-- 
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" 
    integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB" crossorigin="anonymous"> -->


    <!--BOOTSTRAP-->

</head>

<body>

    <!-- Start Header Area -->
    <header class="default-header">
        <div class="container">
            <div class="header-wrap">
                <div class="header-top d-flex justify-content-between align-items-center">
                    <div class="logo">
                        <a href="#home"><img src="img/attendance.png" height="50" width="50" alt=""></a>
                        <h1>My attendence</h1>
                    </div>
                    <div class="main-menubar d-flex align-items-center">
                        <nav class="hide">
                            <a href="index.html">Admin</a>
                            <a href="student.html">Add student</a>
                            <a href="teacher.html">Remove student</a>
                            <a href="about.html">Edit student</a>
                        </nav>
                        <div class="menu-bar"><span class="lnr lnr-menu"></span></div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- End Header Area -->
    </br>
    </br>
    </br>
    </br>
    </br>
    </br>
    </br>
    </br>
    </br>
    </br>

    <!-- start banner Area -->
    <section class="banner-area relative" id="home">
        <div class="container">
            <div class="row fullscreen align-items-center justify-content-center">
                <div class="banner-content col-lg-6 col-md-12">
                    <h1 class="text-uppercase">
                        Add students <br> here
                    </h1>



                    <!--add form aqui-->
                    <div class="panel panel-default" style="margin: 0 auto; width:800px;">

    <div class="panel-heading">
        <h2>
            <a class="btn btn-success" href="add.php">Add student</a>
            <a class="btn btn-info pull-right" href="index.php">Back</a>
        </h2>    
    
    
    
    </div>

    <div class="panel-body">

<!--From-->
<div class='col-md-8'>



<!-- Resize-->
<div class="container-fluid" style="width:800px ">
<div class="card-body" item-height="400px" item-width="400px">
<!--Resize end-->

    <div class="card">
        <div class="card-body" style="background-color:#3498DB;color:#ffffff;"></div>
        <div class="card-body">
             <form class="form-group"  action="func.php" method="post">
             <label>Student name :</label>
             <input type="text" name="Sname" class="form-control" required></br>
             <label>Student ID :</label>
             <input type="text" name="Sid" class="form-control" required></br>
             <label>Student degree :</label>
             <select class="form-control" name="Sdegree" required>
                    <option value="Bachelor of Arts Psychology">Bachelor of Arts Psychology</option>
                    <option value="Bachelor of Arts in Criminal Justice">Bachelor of Arts in Criminal Justice</option>
                    <option value="Bachelor of Arts in international Relations">Bachelor of Arts in international Relations</option>
                    <option value="Bachelor of Arts in Journalism">Bachelor of Arts in Journalism</option>
                    <option value="Bachelor of Pharmacy">Bachelor of Pharmacy</option>
                    <option value="Bachelor of Science in Accounting">Bachelor of Science in Accounting</option>
                    <option value="Bachelor of Science in Applied Computer Technology">Bachelor of Science in Applied Computer Technology</option>
                    <option value="Bachelor of Science in Business Administration">Bachelor of Science in Business Administration</option>
                    <option value="Bachelor of Science in Hotel and Restaurant Management">Bachelor of Science in Hotel and Restaurant Management</option>
                    <option value="Bachelor of Science in information Systems and Technology">Bachelor of Science in information Systems and Technology</option>
                    <option value="Bachelor of Science in international Business Administration">Bachelor of Science in international Business Administration</option>
                    <option value="Bachelor of Science in Tourism Management">Bachelor of Science in Tourism Management</option>
                    <option value="MA in Counselling Psychology">MA in Counselling Psychology</option>
                    <option value="MA in International Relations">MA in International Relations</option>
                    <option value="Master of Arts in Communication Studies">Master of Arts in Communication Studies</option>
                    <option value="Master of Arts in Counseling Psychology">Master of Arts in Counseling Psychology</option>
                    <option value="Master of Arts in international Relations">Master of Arts in international Relations</option>
                    <option value="Master of Business Administration">Master of Business Administration (MBA)</option>
                    <option value="Masters in Information Systems Technology">Masters in Information Systems Technology</option>



                    </select></br>
             <label>Academic year :</label>
             <input type="text" name="Ayear" class="form-control"></br>
             <label>Student device 1 :</label>
             <input type="text" name="Sdevice1" class="form-control"></br>
             <label>Student device 2 :</label>
             <input type="text" name="Sdevice2" class="form-control"></br>
             
             <br>
            <br>
            <button type="submit" name="pat_submit" class="primary-btn2 mt-20 text-uppercase ">
                                    Submit<span class="lnr lnr-arrow-right"></span></button>
             </form>
        
        
        
        
        
        </div>
    </div>

</div>
<div class="col-md-1"></div>
    
<!--Form end-->  
    
    
    </div>




</div>
                    <!--Acaba aqui-->
                    <!--                     <sbr>
                    <br>
                    <br>
                    <p>
                        Don't have an account click the register button<br> and have your account right now.
                    </p>
                    <button clas="primary-btn2 mt-20 text-uppercase ">
                        Register<span class="lnr lnr-arrow-right"></span></button> -->
                </div>
            </div>
        </div>
    </section>
    <!-- End banner Area -->

  
    <script src="js/vendor/jquery-2.2.4.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
    <script src="js/vendor/bootstrap.min.js"></script>
    <script src="js/jquery.ajaxchimp.min.js"></script>
    <script src="js/jquery.nice-select.min.js"></script>
    <script src="js/jquery.sticky.js"></script>
    <script src="js/parallax.min.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/waypoints.min.js"></script>
    <script src="js/jquery.counterup.min.js"></script>
    <script src="js/main.js"></script>
    <!--Jquery-->
    <!-- <script src="https://code.jquery.com/jquery-3.3.1.js" 
    integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60=" crossorigin="anonymous"></script> -->
    <!--Jquery-->
    <!--Bootsrap script-->
    <!--  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" 
    integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T" crossorigin="anonymous"></script> -->
    <!--Bootsrap script-->
</body>

</html>