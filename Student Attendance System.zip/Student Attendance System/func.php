<?php
$con=mysqli_connect("localhost","root","","database1");
if(isset($_POST['login_submit'])){

    $username=$_POST['username'];
    $password=$_POST['password'];
    $query=mysqli_query ($con, "SELECT username,password,type FROM login_tb");
    while ($row=mysqli_fetch_array ($query))
    {
        $db_username = $row("username");
        $db_password = $row("password");
        $db_type = $row("type");

        if ($username==$db_username && $password==$db_password)
        {
            session_start();
            $_SESSION["username"]=$db_username;
            $_SESSION["type"]=$db_type;

            if($_SESSION["type"]=='admin')
            {
                header("Location:admin-panel.php");
            }

            else 
            {
                header("Location:add.php");
            }
        }

        else
        {
            echo "<script>alert('Username or Password is incorret');</script>";
        
                echo"<script>window.open('login.php','_self')</script>";
        }
    }
    /*$query="select * from loelse{
    echo "<script>alert('Username or Password is incorret');</script>";

        echo"<script>window.open('login.php','_self')</script>";}gin_tb where username='$username' and password='$password'";
    $result=mysqli_query($con,$query);
    if(mysqli_num_rows($result)==1)
    {
        header("Location:admin-panel.php");
    } 
    else if (mysqli_num_rows($result)==2)
    {
        header("Location:add2.php");
    } 
    
*/
}

?>