<!DOCTYPE html>
<html lang="zxx" class="no-js">

<head>


    <!-- Mobile Specific Meta -->
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Favicon-->
    <link rel="shortcut icon" href="img/fav.png">
    <!-- Author Meta -->
    <meta name="author" content="Colorlib">
    <!-- Meta Description -->
    <meta name="description" content="">
    <!-- Meta Keyword -->
    <meta name="keywords" content="">
    <!-- meta character set -->
    <meta charset="UTF-8">
    <!-- Site Title -->
    <title>Admin</title>

    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,400,300,500,600,700" rel="stylesheet">
    <!--
			CSS
			============================================= -->
    <link rel="stylesheet" href="css/linearicons.css">=
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/nice-select.css">
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/main.css">
    <!--BOOTSTRAP-->
    <!-- 
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" 
    integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB" crossorigin="anonymous"> -->


    <!--BOOTSTRAP-->

</head>

<body>

    <!-- Start Header Area -->
    <header class="default-header">
        <div class="container">
            <div class="header-wrap">
                <div class="header-top d-flex justify-content-between align-items-center">
                    <div class="logo">
\                        <a href="#home"><img src="img/attendance.png" height="50" width="50" alt=""></a>
                        <h1>My attendence</h1>
                    </div>
                    <div class="main-menubar d-flex align-items-center">
                        <nav class="hide">
                        <a href="index.html">Home</a>
                            <a href="student.html">Student</a>
                            <a href="teacher.html">Teachers</a>
                            <a href="about.html">About</a>>
                        </nav>
                        <div class="menu-bar"><span class="lnr lnr-menu"></span></div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- End Header Area -->

         

    <!-- start banner Area -->
    <section class="banner-area relative" id="home">
    <br>
    <br>
    <br>
        <div class="container">
            <div class="row fullscreen align-items-center justify-content-center">
                <div class="banner-content col-lg-6 col-md-12">
                    <h1 class="text-uppercase">
                        Welcome to the admin area!
                    </h1>
                </div>
                <!--Admin area-->
<div class="container-fluid">
    <div class="row">
        <div class="column">
            <!--<div class="col-md-3">-->
<!-- Resize-->
<div class="container-fluid" style="width:800px ">
<div class="card-body" item-height="400px" item-width="400px">
<!--Resize end-->
<div class="column">
<div class="card">
    <div class="card-body">
        
    <div class="list-group">
                        <a href="" class="list-group-item active"  style="background-color:#3498DB;color:#ffffff;border-color:#3498DB">Students</a>
                        <a href="add.php" class="list-group-item">Add new student</a>
                        <a href="" class="list-group-item">Remove student</a>
                        <a href="" class="list-group-item">Edit student info </a>

                    </div>
                         <hr>
                    <div class="list-group">
                         <a href="" class="list-group-item active " style="background-color:#3498DB;color:#ffffff;border-color:#3498DB">Lecturer</a>
                         <a href="" class="list-group-item">Add new lecturer</a>
                        <a href="" class="list-group-item">Remove lecturer</a>
                        <a href="" class="list-group-item">Edit lecturer  info </a>

                    </div>
                    <hr>
                    <div class="list-group">
                         <a href="" class="list-group-item active " style="background-color:#3498DB;color:#ffffff;border-color:#3498DB">Classes</a>
                         <a href="" class="list-group-item">Add class </a>
                         <a href="" class="list-group-item">Add class time</a>
                        <a href="" class="list-group-item">Remove class</a>
                        <a href="" class="list-group-item">Edit class </a>
                        <a href="" class="list-group-item">Edite class time</a>

                    </div>
                 </div>
    </div>

</div>
<div class="col-md-1"></div>
</div>
</div>
</div>
</div>
</div>

    <!--Admin area end-->
        <!--         <div class="col-lg-6 d-flex align-self-end img-right">
                    <img class="img-fluid" src="b1.jpg" alt="">
                </div>
            </div>
        </div> -->
        </section>
    <!-- End banner Area -->

  
    <!-- End footer Area -->


    <script src="js/vendor/jquery-2.2.4.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
    <script src="js/vendor/bootstrap.min.js"></script>
    <script src="js/jquery.ajaxchimp.min.js"></script>
    <script src="js/jquery.nice-select.min.js"></script>
    <script src="js/jquery.sticky.js"></script>
    <script src="js/parallax.min.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/waypoints.min.js"></script>
    <script src="js/jquery.counterup.min.js"></script>
    <script src="js/main.js"></script>
    <!--Jquery-->
    <!-- <script src="https://code.jquery.com/jquery-3.3.1.js" 
    integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60=" crossorigin="anonymous"></script> -->
    <!--Jquery-->
    <!--Bootsrap script-->
    <!--  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" 
    integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T" crossorigin="anonymous"></script> -->
    <!--Bootsrap script-->
</body>

</html>